
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("Gemini API key not found. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const generateSubtasks = async (taskText: string): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `You are an expert project manager. Break down the following task into a concise list of 2-4 actionable subtasks. Task: "${taskText}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subtasks: {
              type: Type.ARRAY,
              items: {
                type: Type.STRING,
                description: "An actionable subtask."
              }
            }
          },
          required: ["subtasks"]
        }
      }
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);

    if (result && Array.isArray(result.subtasks)) {
      return result.subtasks;
    }
    
    return [];

  } catch (error) {
    console.error("Error generating subtasks with Gemini:", error);
    throw new Error("Failed to generate subtasks. Please check your API key and try again.");
  }
};

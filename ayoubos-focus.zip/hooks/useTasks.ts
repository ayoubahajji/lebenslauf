import { useState, useEffect, useCallback } from 'react';
import type { Task } from '../types';

const INITIAL_TASKS: Task[] = [
    { id: Date.now() + 1, text: "Study B2 German for 2 hours (Wortschatz & Grammatik)", period: "daily", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 2, text: "Check E-com ad spend & fulfillment (1 hour)", period: "daily", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 3, text: "Amor Fati: Accept the situation & execute (10 mins)", period: "daily", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 4, text: "Pass one full B2 mock exam", period: "weekly", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 5, text: "Work on SaaS plan/code (3-5 hours)", period: "weekly", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 6, text: "Test one new product/ad creative for E-com", period: "weekly", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 7, text: "Book B2 Exam (Jan/Feb 2026)", period: "monthly", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 8, text: "Organize 'E-COM SHIELD' tax files", period: "monthly", isComplete: false, subtasks: [], createdAt: new Date().toISOString() },
    { id: Date.now() + 9, text: "Review progress to $100k goal", period: "monthly", isComplete: false, subtasks: [], createdAt: new Date().toISOString() }
];

export const useTasks = () => {
    const [tasks, setTasks] = useState<Task[]>([]);

    useEffect(() => {
        try {
            const storedTasks = localStorage.getItem('ayoubos-tasks');
            if (storedTasks) {
                setTasks(JSON.parse(storedTasks));
            } else {
                setTasks(INITIAL_TASKS);
            }
        } catch (error) {
            console.error("Failed to load tasks from localStorage", error);
            setTasks(INITIAL_TASKS);
        }
    }, []);

    useEffect(() => {
        try {
            if(tasks.length > 0) {
              localStorage.setItem('ayoubos-tasks', JSON.stringify(tasks));
            }
        } catch (error) {
            console.error("Failed to save tasks to localStorage", error);
        }
    }, [tasks]);

    const addTask = useCallback((text: string, period: Task['period']) => {
        const newTask: Task = {
            id: Date.now(),
            text,
            period,
            isComplete: false,
            subtasks: [],
            createdAt: new Date().toISOString()
        };
        setTasks(prev => [newTask, ...prev]);
    }, []);

    const deleteTask = useCallback((id: number) => {
        setTasks(prev => prev.filter(task => task.id !== id));
    }, []);

    const toggleTaskCompletion = useCallback((id: number, isComplete: boolean) => {
        setTasks(prev => prev.map(task =>
            task.id === id ? { ...task, isComplete } : task
        ));
    }, []);

    const addSubtask = useCallback((taskId: number, subtaskText: string) => {
        setTasks(prev => prev.map(task =>
            task.id === taskId
                ? { ...task, subtasks: [...task.subtasks, subtaskText] }
                : task
        ));
    }, []);

    const updateTaskText = useCallback((taskId: number, newText: string) => {
        setTasks(prev => prev.map(task => 
            task.id === taskId ? { ...task, text: newText } : task
        ));
    }, []);

    return {
        tasks,
        addTask,
        deleteTask,
        toggleTaskCompletion,
        addSubtask,
        updateTaskText
    };
};
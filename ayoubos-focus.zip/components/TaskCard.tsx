import React, { useState, useRef, useEffect } from 'react';
import type { Task, Notification } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';

interface TaskCardProps {
  task: Task;
  setDraggedTaskId: (id: number | null) => void;
  onDelete: (id: number) => void;
  onAddSubtask: (taskId: number, subtaskText: string) => void;
  onUpdateText: (taskId: number, newText: string) => void;
  showNotification: (message: string, type: Notification['type']) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, setDraggedTaskId, onDelete, onAddSubtask, onUpdateText, showNotification }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentText, setCurrentText] = useState(task.text);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [isEditing]);

  const handleDragStart = (e: React.DragEvent) => {
    if (isEditing) {
      e.preventDefault();
      return;
    }
    setDraggedTaskId(task.id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDelete = () => {
    onDelete(task.id);
    showNotification("Task deleted", "info");
  }

  const handleAddSubtask = () => {
    const subtaskText = prompt('Enter sub-task:');
    if (subtaskText && subtaskText.trim()) {
      onAddSubtask(task.id, subtaskText.trim());
      showNotification("Sub-task added!", "success");
    }
  }

  const handleDoubleClick = () => {
    if (!task.isComplete) {
      setIsEditing(true);
    }
  };

  const handleUpdate = () => {
    if (currentText.trim() === '') {
      setCurrentText(task.text);
      showNotification("Task cannot be empty.", "error");
    } else if (currentText.trim() !== task.text) {
      onUpdateText(task.id, currentText.trim());
      showNotification("Task updated!", "success");
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleUpdate();
    } else if (e.key === 'Escape') {
      setCurrentText(task.text);
      setIsEditing(false);
    }
  };

  return (
    <article
      className="task-card bg-white/10 backdrop-blur-md border border-white/15 shadow-md rounded-xl p-3 md:p-4 slide-in cursor-grab active:cursor-grabbing"
      draggable={!isEditing}
      onDragStart={handleDragStart}
      onDragEnd={() => setDraggedTaskId(null)}
    >
      <div className="flex items-start justify-between">
        {isEditing ? (
          <input
            ref={inputRef}
            type="text"
            value={currentText}
            onChange={(e) => setCurrentText(e.target.value)}
            onBlur={handleUpdate}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-white/20 rounded-md p-1 -m-1 text-white placeholder-white/70 focus:bg-white/25 focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 focus:outline-none transition-all duration-300 w-full"
          />
        ) : (
          <p 
            onDoubleClick={handleDoubleClick}
            className={`text-white text-sm md:text-base break-words pr-2 w-full ${task.isComplete ? 'line-through text-white/50' : 'cursor-text'}`}
            title={task.isComplete ? '' : 'Double-click to edit'}
          >
            {task.text}
          </p>
        )}
        <div className="flex space-x-2 md:space-x-3 flex-shrink-0 ml-3">
          {!task.isComplete && (
            <button 
              onClick={handleAddSubtask}
              className="text-white/60 hover:text-blue-400 transition-colors" 
              title="Add sub-task"
            >
              <PlusIcon />
            </button>
          )}
          <button onClick={handleDelete} className="text-white/60 hover:text-red-400 transition-colors" title="Delete">
            <TrashIcon />
          </button>
        </div>
      </div>
      {task.subtasks && task.subtasks.length > 0 && (
        <div className="subtask-container mt-2">
          <ul className="list-disc list-inside mt-2 pl-2 space-y-1">
            {task.subtasks.map((sub, index) => (
              <li key={index} className="text-sm text-white/70">{sub}</li>
            ))}
          </ul>
        </div>
      )}
    </article>
  );
};

export default TaskCard;
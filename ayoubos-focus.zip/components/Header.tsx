
import React from 'react';

const Header = () => {
  return (
    <header className="bg-white/10 backdrop-blur-xl border-b border-white/20 p-4 md:p-6 flex-shrink-0 m-3 mb-2 md:mb-3 rounded-2xl">
        <p className="text-xs md:text-sm font-semibold uppercase tracking-wider text-blue-300">Your North Star</p>
        <p className="text-base md:text-lg lg:text-xl font-bold text-white">FOCUS ON YOUR GOAL: Be free. Create. Don't worry about money. Execute the plan.</p>
    </header>
  );
};

export default Header;

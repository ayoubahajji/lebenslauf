
import React from 'react';

const Sidebar = () => {
  return (
    <nav className="w-full md:w-80 md:h-screen bg-white/10 backdrop-blur-2xl border-r border-white/20 shadow-lg p-4 md:p-6 flex flex-col m-2 md:m-3 flex-shrink-0 rounded-2xl md:rounded-r-none md:rounded-l-2xl">
        <div className="flex-shrink-0">
            <h1 className="text-2xl md:text-3xl font-bold text-white mb-6 md:mb-10">Ayoub<span className="text-blue-400">OS</span></h1>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-white/70 mb-3">Your Mission</h2>
            <p className="text-base md:text-lg font-bold text-white leading-tight">
                Pass B2. Get to Germany. Build your SaaS &amp; E-com to hit <span className="text-blue-400">$100k</span>. Quit the job. Be free.
            </p>
        </div>

        <div className="mt-6 md:mt-10 border-t border-white/20 pt-4 md:pt-6 flex-shrink-0">
            <h2 className="text-xs font-semibold uppercase tracking-widest text-white/70 mb-4">FINANCIAL "BUCKETS"</h2>
            <p className="text-sm mb-4 text-white/80">Your anxiety is gone. Your money has a plan.</p>
            <div className="space-y-3 md:space-y-4">
                <div className="bg-white/10 backdrop-blur-md border border-white/15 shadow-md rounded-xl p-3 md:p-4">
                    <p className="text-xs md:text-sm text-white/70">GERMANY FUND (Locked)</p>
                    <p className="text-lg md:text-2xl font-bold text-white">$16,000</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md border border-white/15 shadow-md rounded-xl p-3 md:p-4">
                    <p className="text-xs md:text-sm text-white/70">GHOST FUND (Quarantined)</p>
                    <p className="text-lg md:text-2xl font-bold text-white">$8,140</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md border border-white/15 shadow-md rounded-xl p-3 md:p-4">
                    <p className="text-xs md:text-sm text-white/70">SAFETY NET (Your Salary)</p>
                    <p className="text-lg md:text-2xl font-bold text-white">$8,910</p>
                </div>
            </div>
        </div>
        <div className="mt-auto pt-4 md:pt-6 border-t border-white/20 flex-shrink-0">
            <p className="text-xs text-white/60">You are not starting from zero. You are starting from <strong className="text-white">$33,050</strong> and <strong className="text-white">experience</strong>.</p>
        </div>
    </nav>
  );
};

export default Sidebar;

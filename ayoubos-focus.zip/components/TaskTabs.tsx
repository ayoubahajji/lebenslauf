
import React from 'react';
import type { Period } from '../types';

interface TaskTabsProps {
  currentPeriod: Period;
  onTabChange: (period: Period) => void;
}

const TabButton: React.FC<{
    period: Period;
    label: string;
    currentPeriod: Period;
    onClick: (period: Period) => void;
}> = ({ period, label, currentPeriod, onClick }) => {
    const isActive = currentPeriod === period;
    const activeClasses = "bg-blue-500 text-white font-bold border-transparent shadow-[0_4px_14px_rgba(0,118,255,0.4)]";
    const inactiveClasses = "bg-white/10 text-white/80 border border-white/20 hover:bg-white/20";

    return (
        <button
            onClick={() => onClick(period)}
            className={`py-2 md:py-3 px-4 md:px-6 text-sm md:text-base whitespace-nowrap rounded-full transition-all duration-300 ${isActive ? activeClasses : inactiveClasses}`}
        >
            {label}
        </button>
    );
};


const TaskTabs: React.FC<TaskTabsProps> = ({ currentPeriod, onTabChange }) => {
  return (
    <div className="pb-2 md:pb-3 flex-shrink-0">
      <div className="flex space-x-2 md:space-x-4 overflow-x-auto">
        <TabButton period="daily" label="Daily" currentPeriod={currentPeriod} onClick={onTabChange} />
        <TabButton period="weekly" label="Weekly" currentPeriod={currentPeriod} onClick={onTabChange} />
        <TabButton period="monthly" label="Monthly" currentPeriod={currentPeriod} onClick={onTabChange} />
      </div>
    </div>
  );
};

export default TaskTabs;

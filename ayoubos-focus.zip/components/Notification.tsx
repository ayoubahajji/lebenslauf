
import React, { useEffect, useState } from 'react';
import type { Notification as NotificationType } from '../types';

interface NotificationProps {
  notification: NotificationType;
  onClose: () => void;
}

const Notification: React.FC<NotificationProps> = ({ notification, onClose }) => {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setExiting(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (exiting) {
      const timer = setTimeout(onClose, 300); // Match animation duration
      return () => clearTimeout(timer);
    }
  }, [exiting, onClose]);

  const baseClasses = "py-3 px-5 rounded-xl text-white font-medium shadow-lg";
  const typeClasses = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    info: 'bg-blue-500',
  };

  return (
    <div className={`${baseClasses} ${typeClasses[notification.type]} ${exiting ? 'notification-exit' : 'notification-enter'}`}>
      {notification.message}
    </div>
  );
};

export default Notification;

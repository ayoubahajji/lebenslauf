import React, { useState } from 'react';
import type { Task, Notification } from '../types';
import TaskCard from './TaskCard';

interface KanbanColumnProps {
  title: string;
  tasks: Task[];
  onDrop: () => void;
  setDraggedTaskId: (id: number | null) => void;
  deleteTask: (id: number) => void;
  addSubtask: (taskId: number, subtaskText: string) => void;
  updateTaskText: (taskId: number, newText: string) => void;
  showNotification: (message: string, type: Notification['type']) => void;
}

const KanbanColumn: React.FC<KanbanColumnProps> = ({ title, tasks, onDrop, setDraggedTaskId, deleteTask, addSubtask, updateTaskText, showNotification }) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    onDrop();
  };
  
  const titleClass = title === 'DONE' ? 'text-white/60' : 'text-white';
  const dragOverClass = isDragOver ? 'border-2 border-dashed border-blue-400 bg-blue-500/10' : '';

  return (
    <section 
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`bg-white/10 backdrop-blur-2xl border border-white/20 shadow-lg rounded-2xl p-3 md:p-4 flex flex-col md:h-full transition-all duration-300 ${dragOverClass}`}
    >
      <h2 className={`text-lg md:text-2xl font-bold mb-4 md:mb-6 flex-shrink-0 ${titleClass}`}>{title}</h2>
      <div className="task-list space-y-3 md:space-y-4 pr-2 md:flex-1 md:overflow-y-auto">
        {tasks.map(task => (
          <TaskCard
            key={task.id}
            task={task}
            setDraggedTaskId={setDraggedTaskId}
            onDelete={deleteTask}
            onAddSubtask={addSubtask}
            onUpdateText={updateTaskText}
            showNotification={showNotification}
          />
        ))}
      </div>
    </section>
  );
};

export default KanbanColumn;
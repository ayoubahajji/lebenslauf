
import React, { useState } from 'react';

interface TaskInputProps {
  onAddTask: (text: string) => void;
}

const TaskInput: React.FC<TaskInputProps> = ({ onAddTask }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAddTask(text.trim());
      setText('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="pb-3 md:pb-4 flex-shrink-0">
      <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 md:space-x-4">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="flex-1 bg-white/15 backdrop-blur-sm border border-white/20 rounded-full p-3 md:p-4 text-white placeholder-white/70 focus:bg-white/25 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 focus:outline-none transition-all duration-300"
          placeholder="Add a new task..."
          required
        />
        <button
          type="submit"
          className="bg-blue-500 text-white font-bold py-2 md:py-3 px-4 md:px-6 rounded-full hover:bg-blue-600 transition-all duration-300 ease-in-out whitespace-nowrap"
        >
          Add
        </button>
      </div>
    </form>
  );
};

export default TaskInput;


import React from 'react';
import type { Notification as NotificationType } from '../types';
import Notification from './Notification';

interface NotificationContainerProps {
  notifications: NotificationType[];
  removeNotification: (id: number) => void;
}

const NotificationContainer: React.FC<NotificationContainerProps> = ({ notifications, removeNotification }) => {
  return (
    <div className="fixed top-5 right-5 z-50 space-y-3">
      {notifications.map(notification => (
        <Notification
          key={notification.id}
          notification={notification}
          onClose={() => removeNotification(notification.id)}
        />
      ))}
    </div>
  );
};

export default NotificationContainer;

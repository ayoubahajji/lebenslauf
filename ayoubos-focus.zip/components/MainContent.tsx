import React, { useState, useMemo } from 'react';
import type { Task, Period, Notification } from '../types';
import Header from './Header';
import TaskTabs from './TaskTabs';
import TaskInput from './TaskInput';
import KanbanColumn from './KanbanColumn';

interface MainContentProps {
  tasks: Task[];
  addTask: (text: string, period: Period) => void;
  deleteTask: (id: number) => void;
  toggleTaskCompletion: (id: number, isComplete: boolean) => void;
  addSubtask: (taskId: number, subtaskText: string) => void;
  updateTaskText: (taskId: number, newText: string) => void;
  showNotification: (message: string, type: Notification['type']) => void;
}

const MainContent: React.FC<MainContentProps> = ({ 
  tasks, 
  addTask, 
  deleteTask, 
  toggleTaskCompletion, 
  addSubtask,
  updateTaskText,
  showNotification
}) => {
  const [currentPeriod, setCurrentPeriod] = useState<Period>('daily');
  const [draggedTaskId, setDraggedTaskId] = useState<number | null>(null);

  const handleAddTask = (text: string) => {
    addTask(text, currentPeriod);
    showNotification("Task added!", "success");
  };

  const handleDrop = (isDoneColumn: boolean) => {
    if (draggedTaskId !== null) {
      const task = tasks.find(t => t.id === draggedTaskId);
      if (task && task.isComplete !== isDoneColumn) {
        toggleTaskCompletion(draggedTaskId, isDoneColumn);
        showNotification(isDoneColumn ? "Task completed!" : "Task moved to To-Do", "success");
      }
      setDraggedTaskId(null);
    }
  };

  const filteredTasks = useMemo(() =>
    tasks.filter(task => task.period === currentPeriod),
    [tasks, currentPeriod]
  );

  const todoTasks = filteredTasks.filter(task => !task.isComplete);
  const doneTasks = filteredTasks.filter(task => task.isComplete);

  return (
    <main className="flex-1 flex flex-col md:overflow-hidden">
      <Header />
      <div className="px-4 md:px-6">
        <TaskTabs currentPeriod={currentPeriod} onTabChange={setCurrentPeriod} />
      </div>
      <div className="px-4 md:px-6">
        <TaskInput onAddTask={handleAddTask} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-6 p-4 md:p-6 md:flex-1 md:overflow-hidden">
        <KanbanColumn
          title="TO-DO"
          tasks={todoTasks}
          onDrop={() => handleDrop(false)}
          setDraggedTaskId={setDraggedTaskId}
          deleteTask={deleteTask}
          addSubtask={addSubtask}
          updateTaskText={updateTaskText}
          showNotification={showNotification}
        />
        <KanbanColumn
          title="DONE"
          tasks={doneTasks}
          onDrop={() => handleDrop(true)}
          setDraggedTaskId={setDraggedTaskId}
          deleteTask={deleteTask}
          addSubtask={addSubtask}
          updateTaskText={updateTaskText}
          showNotification={showNotification}
        />
      </div>
    </main>
  );
};

export default MainContent;
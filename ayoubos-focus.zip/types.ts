export type Period = 'daily' | 'weekly' | 'monthly';

export interface Task {
  id: number;
  text: string;
  period: Period;
  isComplete: boolean;
  subtasks: string[];
  createdAt: string; // ISO string
}

export interface Notification {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}
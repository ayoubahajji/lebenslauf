import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import NotificationContainer from './components/NotificationContainer';
import { useTasks } from './hooks/useTasks';
import type { Notification, Task } from './types';

function App() {
  const { 
    tasks, 
    addTask, 
    deleteTask, 
    toggleTaskCompletion, 
    addSubtask,
    updateTaskText
  } = useTasks();

  const [notifications, setNotifications] = useState<Notification[]>([]);

  const showNotification = (message: string, type: Notification['type']) => {
    const newNotification = {
      id: Date.now(),
      message,
      type,
    };
    setNotifications(prev => [...prev, newNotification]);
  };

  const removeNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };
  
  return (
    <div className="flex flex-col md:flex-row md:h-screen bg-gradient-to-br from-[#667eea] to-[#764ba2] text-white md:overflow-hidden min-h-screen">
      <Sidebar />
      <MainContent
        tasks={tasks}
        addTask={addTask}
        deleteTask={deleteTask}
        toggleTaskCompletion={toggleTaskCompletion}
        addSubtask={addSubtask}
        updateTaskText={updateTaskText}
        showNotification={showNotification}
      />
      <NotificationContainer 
        notifications={notifications}
        removeNotification={removeNotification}
      />
    </div>
  );
}

export default App;